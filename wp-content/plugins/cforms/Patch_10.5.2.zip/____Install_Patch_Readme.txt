
v10.5 Patch 1 Instructions
--------------------------

Simply extract/copy all files into your cforms folder.


Patch 1 includes:
~~~~~~~~~~~~~~~~~
*) feature: Email Priority can now be set under "Core Options"
*) bugfix:  insert_cform('1') would cause minor issues if your default form was a TAF form
*) bugfix:  Limit Text is now saved even if no #-limit is provided
*) bugfix:  fixed =3D issue for some users (admin email layout)

